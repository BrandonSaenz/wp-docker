<?php get_sidebar(); ?>
</div>
<footer id="footer" role="contentinfo">
<?php wp_footer(); ?>
</body>
</html>